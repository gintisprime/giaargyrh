package com.example.a1234;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;

public class BluetoothAdapter extends AppCompatActivity {

    // UUID for Serial Port Profile (SPP)
    private static final UUID OBD_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket socket;

    public BluetoothAdapter() {
        // Initialize Bluetooth adapter
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    }

    public boolean connectToOBD(String deviceName, String deviceAddress) {
        if (bluetoothAdapter == null) {
            // Device does not support Bluetooth
            System.out.println("Bluetooth not supported on this device");
            return false;
        }

        // Find the OBD-II device (by name or MAC address)
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        BluetoothDevice obdDevice = null;

        for (BluetoothDevice device : pairedDevices) {
            if (device.getName().equals(deviceName) || device.getAddress().equals(deviceAddress)) {
                obdDevice = device;
                break;
            }
        }

        if (obdDevice == null) {
            System.out.println("OBD-II device not found");
            return false;
        }

        try {
            // Open Bluetooth socket to OBD device
            socket = obdDevice.createRfcommSocketToServiceRecord(OBD_UUID);
            socket.connect(); // Connect to the device

            System.out.println("Connected to OBD-II device");
            return true;

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Connection to OBD-II device failed");
            return false;
        }
    }

    public void disconnect() {
        if (socket != null) {
            try {
                socket.close();
                System.out.println("Disconnected from OBD-II device");
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Failed to disconnect from OBD-II device");
            }
        }
    }

    public BluetoothSocket getSocket() {
        return socket;
    }
}